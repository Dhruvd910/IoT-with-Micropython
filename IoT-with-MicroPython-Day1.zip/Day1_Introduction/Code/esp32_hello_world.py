print("Hello from ESP32 with MicroPython!")
