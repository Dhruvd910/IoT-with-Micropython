print("Hello from Raspberry Pi with Python!")
